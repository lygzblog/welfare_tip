window.ENV_CONFIG = {
    //后端授权的域名 例如：http://cs.xxx.xn
    VITE_API_URL: "http://tipapi.ptger.cn",
};